<?php
session_start();

// منع التخزين المؤقت لضمان تسجيل الخروج الفعلي وعدم العودة بالخلف
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// --- 1. معالجة تسجيل الخروج (عند الضغط على Logout أو Home) ---
if (isset($_GET['logout'])) {
    $_SESSION = array(); 
    session_destroy(); 
    header("Location: index.html"); 
    exit();
}

// --- 2. إعدادات كلمة المرور ---
$admin_password = "admin2026"; 

if (isset($_POST['login_submit'])) {
    if ($_POST['login_pass'] === $admin_password) {
        $_SESSION['authenticated'] = true;
    } else {
        $login_error = "Invalid Password!";
    }
}

// --- 3. حاجز الحماية (إذا لم يسجل الدخول يظهر كرت الدخول فقط) ---
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Login | Admin Access</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root { --tu-blue: #1E3A8A; --tu-gold: #D4AF37; }
        body { height: 100vh; display: flex; align-items: center; justify-content: center; background: #f1f5f9; }
        .login-card { width: 400px; border-radius: 20px; border-top: 8px solid var(--tu-gold); box-shadow: 0 15px 35px rgba(0,0,0,0.1); background: white; padding: 40px; text-align: center; }
        .btn-login { background: var(--tu-blue); color: white; font-weight: 700; border-radius: 10px; padding: 12px; border: none; width: 100%; transition: 0.3s; }
        .btn-login:hover { background: #152a63; transform: translateY(-2px); }
    </style>
</head>
<body>
    <div class="login-card animate__animated animate__zoomIn">
        <img src="images/logo-taif.png" style="height: 70px; margin-bottom: 20px;">
        <h4 style="color: var(--tu-blue); font-weight: 800;">ADMIN LOGIN</h4>
        <p class="text-muted small">Networking Project Management</p>
        <?php if(isset($login_error)) echo "<div class='alert alert-danger p-2 small'>$login_error</div>"; ?>
        <form method="POST">
            <input type="password" name="login_pass" class="form-control mb-3 shadow-sm" placeholder="Enter Password" required>
            <button type="submit" name="login_submit" class="btn btn-login shadow">LOGIN</button>
            <a href="index.html" class="d-block mt-3 small text-muted">Go to Home Page</a>
        </form>
    </div>
</body>
</html>
<?php 
exit(); 
endif;

// --- 4. كود قاعدة البيانات والتحكم (يظهر فقط بعد الدخول) ---
$conn = new mysqli("localhost", "root", "", "quiz_db");
if ($conn->connect_error) { die("Database Error!"); }

$message = ""; $update_mode = false;
$id = 0; $q_text = ""; $opt1 = ""; $opt2 = ""; $opt3 = ""; $opt4 = ""; $correct = "";

// حفظ سؤال
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_question'])) {
    $q_text = $conn->real_escape_string($_POST['q_text']);
    $opt1 = $conn->real_escape_string($_POST['opt1']);
    $opt2 = $conn->real_escape_string($_POST['opt2']);
    $opt3 = $conn->real_escape_string($_POST['opt3']);
    $opt4 = $conn->real_escape_string($_POST['opt4']);
    $correct = (int)$_POST['q_correct'];
    $conn->query("INSERT INTO questions (question_text, option1, option2, option3, option4, correct_option) VALUES ('$q_text', '$opt1', '$opt2', '$opt3', '$opt4', '$correct')");
    $message = "<div class='alert alert-success shadow-sm'>Successfully Added!</div>";
}

// حذف سؤال
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM questions WHERE question_id=$id");
    $message = "<div class='alert alert-danger shadow-sm'>Question Deleted.</div>";
}

// تعديل سؤال
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $update_mode = true;
    $res = $conn->query("SELECT * FROM questions WHERE question_id=$id");
    if($row = $res->fetch_assoc()){
        $q_text = $row['question_text']; $opt1 = $row['option1']; $opt2 = $row['option2']; 
        $opt3 = $row['option3']; $opt4 = $row['option4']; $correct = $row['correct_option'];
    }
}

// تحديث سؤال
if (isset($_POST['update_question'])) {
    $id = $_POST['id'];
    $q_text = $conn->real_escape_string($_POST['q_text']);
    $opt1 = $_POST['opt1']; $opt2 = $_POST['opt2']; $opt3 = $_POST['opt3']; $opt4 = $_POST['opt4'];
    $correct = $_POST['q_correct'];
    $conn->query("UPDATE questions SET question_text='$q_text', option1='$opt1', option2='$opt2', option3='$opt3', option4='$opt4', correct_option='$correct' WHERE question_id=$id");
    header("Location: admin.php");
    exit();
}

$result = $conn->query("SELECT * FROM questions ORDER BY question_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard | Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <style>
        :root { --tu-blue: #1E3A8A; --tu-gold: #D4AF37; }
        body { padding-top: 130px; background-color: #f8f9fa; }
        .header { background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 100%; }
        .admin-card { border-radius: 15px; border-top: 8px solid var(--tu-gold); background: #fff; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .footer { background: #020617; color: #94a3b8; border-top: 4px solid var(--tu-gold); width: 100%; }
    </style>
</head>
<body>

<header class="fixed-top header">
    <div class="container-fluid px-4">
        <nav class="navbar navbar-expand-lg navbar-light py-2">
            <a class="navbar-brand d-flex align-items-center" href="admin.php?logout=1">
                <img src="images/logo-taif.png" alt="Logo" style="height: 55px;">
                <div class="ml-3 border-left pl-3 d-none d-sm-block">
                    <strong style="color: var(--tu-blue); display:block;">University College at Khurma</strong>
                    <small style="color: #666; font-weight: bold;">Computer Science Department</small>
                </div>
            </a>
            <div class="ml-auto">
                <ul class="navbar-nav flex-row">
                    <li class="nav-item mx-2"><a class="nav-link font-weight-bold" href="admin.php?logout=1">Home</a></li>
                    <li class="nav-item mx-2"><a class="nav-link text-danger font-weight-bold" href="admin.php?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<main class="container py-4">
    <?php echo $message; ?>

    <div class="card admin-card p-4 mb-5 shadow">
        <h3 style="color: var(--tu-blue); font-weight: 800;"><?php echo $update_mode ? "Edit Question" : "Add New Question"; ?></h3>
        <hr>
        <form method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label class="font-weight-bold">Question Text</label>
                <input type="text" name="q_text" class="form-control" value="<?php echo $q_text; ?>" required>
            </div>
            <div class="row">
                <div class="col-md-3 mb-2"><label>Option 1</label><input type="text" name="opt1" class="form-control" value="<?php echo $opt1; ?>" required></div>
                <div class="col-md-3 mb-2"><label>Option 2</label><input type="text" name="opt2" class="form-control" value="<?php echo $opt2; ?>" required></div>
                <div class="col-md-3 mb-2"><label>Option 3</label><input type="text" name="opt3" class="form-control" value="<?php echo $opt3; ?>" required></div>
                <div class="col-md-3 mb-2"><label>Option 4</label><input type="text" name="opt4" class="form-control" value="<?php echo $opt4; ?>" required></div>
            </div>
            <div class="form-group mt-3">
                <label class="font-weight-bold text-primary">Correct Answer</label>
                <select name="q_correct" class="form-control" style="border-left: 5px solid var(--tu-gold);">
                    <option value="1" <?php if($correct==1) echo "selected";?>>Option 1</option>
                    <option value="2" <?php if($correct==2) echo "selected";?>>Option 2</option>
                    <option value="3" <?php if($correct==3) echo "selected";?>>Option 3</option>
                    <option value="4" <?php if($correct==4) echo "selected";?>>Option 4</option>
                </select>
            </div>
            <button type="submit" name="<?php echo $update_mode ? 'update_question' : 'save_question'; ?>" class="btn btn-login btn-block shadow-sm">
                <i class="fas fa-check-circle mr-2"></i> <?php echo $update_mode ? 'Save Changes' : 'Add Question'; ?>
            </button>
        </form>
    </div>

    <div class="table-responsive bg-white p-3 shadow-sm rounded border">
        <table class="table table-hover">
            <thead style="background: var(--tu-blue); color: white;">
                <tr>
                    <th>ID</th>
                    <th>Question</th>
                    <th>Correct</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td>#<?php echo $row['question_id']; ?></td>
                    <td><?php echo $row['question_text']; ?></td>
                    <td><span class="badge badge-success px-3">Option <?php echo $row['correct_option']; ?></span></td>
                    <td>
                        <a href="admin.php?edit=<?php echo $row['question_id']; ?>" class="btn btn-sm btn-info mr-1"><i class="fas fa-pen"></i></a>
                        <a href="admin.php?delete=<?php echo $row['question_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this question?')"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>

<footer class="footer py-5" style="background: #020617; color: #94a3b8; border-top: 4px solid #D4AF37;">
        <div class="container-fluid text-center"> <img src="images/logo-taif.png" style="height: 65px; filter: brightness(0) invert(1); margin-bottom: 25px;" alt="Taif University Logo">
            <p class="mb-1 text-white" style="font-size: 1.1rem; font-weight: 700;">
                Taif University - University College at Khurma
            </p>
            <p class="mb-4" style="letter-spacing: 1px; font-weight: 500;">
                Department of Computer Science
            </p>
            <div class="row justify-content-center mb-4 text-center">
                <div class="col-auto"><span class="badge px-4 py-2 shadow-sm" style="background:#D4AF37; color:white; border-radius: 50px; font-weight: 600; font-size: 0.85rem;">Section: 286</span></div>
                <div class="col-auto"><span class="badge px-4 py-2 shadow-sm" style="background:#D4AF37; color:white; border-radius: 50px; font-weight: 600; font-size: 0.85rem;">Project 2026</span></div>
            </div>
            <hr style="background-color: #334155; width: 60%; margin: 30px auto;">
            <p class="small text-muted" style="font-style: italic;">Developed for Educational Purposes © 2026 | Networking Course Project</p>
        </div>
    </footer>

</body>
</html>