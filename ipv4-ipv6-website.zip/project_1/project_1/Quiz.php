<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = new mysqli($servername, $username, $password);

// إنشاء القاعدة
$conn->query("CREATE DATABASE IF NOT EXISTS quiz_db");
$conn->select_db("quiz_db");

// إنشاء الجدول
$table_sql = "CREATE TABLE IF NOT EXISTS questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    question_text TEXT NOT NULL,
    option1 VARCHAR(255),
    option2 VARCHAR(255),
    option3 VARCHAR(255),
    option4 VARCHAR(255),
    correct_option INT
)";
$conn->query($table_sql);

// التحقق من عدد الأسئلة - إذا كان أقل من 5 أسئلة، سنضيف البقية
$check = $conn->query("SELECT * FROM questions");
if ($check->num_rows <= 1) {
    // مصفوفة الأسئلة الجديدة
    $extra_questions = [
        ['How many bits are in an IPv4 address?', '32 bits', '64 bits', '128 bits', '256 bits', 1],
        ['Which of these is a valid IPv6 address?', '192.168.1.1', '2001:0db8:85a3::8a2e:0370:7334', '10.0.0.255', 'FF-EE-DD-CC-BB-AA', 2],
        ['What is the main purpose of Dual Stack?', 'To replace IPv4 entirely', 'To run IPv4 and IPv6 simultaneously', 'To encrypt web traffic', 'To speed up the internet', 2],
        ['Which protocol is used to assign IP addresses automatically?', 'DNS', 'HTTP', 'DHCP', 'FTP', 3],
        ['What does the "Loopback Address" 127.0.0.1 refer to?', 'The Router', 'The Server', 'The Local Host (My Device)', 'The Gateway', 3]
    ];

    foreach ($extra_questions as $q) {
        $stmt = $conn->prepare("INSERT INTO questions (question_text, option1, option2, option3, option4, correct_option) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssi", $q[0], $q[1], $q[2], $q[3], $q[4], $q[5]);
        $stmt->execute();
    }
}

// جلب البيانات بالكامل
$result = $conn->query("SELECT * FROM questions");
$db_questions = [];
if ($result) {
    while($row = $result->fetch_assoc()) {
        $db_questions[] = [
            "q" => $row['question_text'],
            "options" => [$row['option1'], $row['option2'], $row['option3'], $row['option4']],
            "correct" => (int)$row['correct_option'] - 1
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Interactive Quiz | Networking Knowledge</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
  
  <style>
    :root {
      --tu-blue: #1E3A8A;
      --tu-gold: #D4AF37;
    }

    body { padding-top: 90px; background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }

    /* --- الهيدر الموحد (مطابق للـ Lookup Tool) --- */
    

    /* --- قسم العنوان الموحد --- */
    .page-title-section { padding: 160px 0 70px; background: linear-gradient(135deg, #020617 0%, #1e3a8a 100%); text-align: center; border-bottom: 5px solid var(--tu-gold); width: 100%; }
    .text-yellow-gradient { background: linear-gradient(to right, #D4AF37, #ffe082); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; font-weight: 900; }

    /* --- حاوية الكويز الموحدة --- */
    .quiz-main-container { max-width: 1100px; margin: -60px auto 50px; position: relative; z-index: 10; padding: 0 15px; }
    .quiz-card { background: #fff; border-radius: 20px; padding: 50px; box-shadow: 0 15px 50px rgba(0, 0, 0, 0.1); border-top: 8px solid var(--tu-gold); }

    /* --- تنسيق الخيارات --- */
    .option-item { display: block; width: 100%; padding: 20px; margin-bottom: 15px; border: 2px solid #f0f0f0; border-radius: 12px; text-align: left; font-size: 1.1rem; cursor: pointer; transition: 0.3s; background: #fff; font-weight: 600; color: #475569; }
    .option-item:hover { transform: translateX(10px); border-color: var(--tu-gold); background: #fffdf2; color: var(--tu-blue); }
    
    .is-correct { background-color: #d4edda !important; border-color: #28a745 !important; color: #155724 !important; }
    .is-wrong { background-color: #f8d7da !important; border-color: #dc3545 !important; color: #721c24 !important; }

    /* --- الفوتر الموحد --- */
    .footer { background: #020617; color: #94a3b8; border-top: 4px solid #D4AF37; padding: 60px 0; width: 100%; }
    .header, .footer { width: 100%; }
  </style>
</head>
<body>

 <header class="fixed-top header">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light py-2">
                <a class="navbar-brand d-flex align-items-center" href="index.html">
                    <img src="images/logo-taif.png" alt="Taif University Logo" style="height: 55px;">
                    <div class="ml-3 border-left pl-3 d-none d-sm-block text-left">
                        <strong style="display:block; font-size: 1.1rem; color: #1E3A8A;">University College at Khurma</strong>
                        <small style="font-size: 11px; color: #666; font-weight: bold; text-transform: uppercase;">Computer Science Department</small>
                    </div>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navigation">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item "><a class="nav-link" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="ipv4.html">IPv4</a></li>
                        <li class="nav-item "><a class="nav-link" href="ipv6.html">IPv6</a></li>
                        <li class="nav-item"><a class="nav-link" href="transition.html">Transition</a></li>
                        <li class="nav-item"><a class="nav-link" href="lookup.html">Lookup Tool</a></li>
                        <li class="nav-item active"><a class="nav-link" href="quiz.php">Quizzes</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.html">About Us</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

<section class="page-title-section">
    <div class="container-fluid-custom">
        <h1 class="display-3 text-white font-weight-bold animate__animated animate__backInDown">
            Knowledge <span class="text-yellow-gradient">Challenge</span>
        </h1>
        <p class="text-white-50 mt-3 animate__animated animate__fadeInUp animate__delay-1s" style="font-size: 1.5rem;">
            Prove your expertise in Networking Protocols
        </p>
    </div>
</section>

<div class="container-fluid-custom quiz-main-container">
    <div class="quiz-card animate__animated animate__fadeInUp">
        <div id="quiz-active">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <span id="q-number" class="h4 text-primary font-weight-bold m-0">Question 1</span>
                <span id="score-text" class="h5 text-muted m-0">Score: 0</span>
            </div>
            <div class="progress mb-5" style="height: 12px; border-radius: 20px; background-color: #f1f5f9;">
                <div id="p-bar" class="progress-bar bg-warning" style="width: 0%; border-radius: 20px;"></div>
            </div>
            <h2 id="q-text" class="mb-5 text-dark" style="font-size: 2.2rem; font-weight: 700; line-height: 1.3;">Loading...</h2>
            <div id="options-box" class="row">
                </div>
        </div>

        <div id="result-area" style="display: none; text-align: center;" class="animate__animated animate__zoomIn">
            <h2 class="display-4 font-weight-bold text-dark">Quiz Completed! 🎓</h2>
            <div style="font-size: 6rem; color: var(--tu-gold); font-weight: 900;" id="final-score-display">0/0</div>
            <p class="h4 text-muted mb-4">Great effort! Keep learning.</p>
            <button class="btn btn-primary btn-lg mt-2 px-5 py-3 rounded-pill shadow-lg font-weight-bold" style="background: var(--tu-blue); border: none;" onclick="location.reload()">RESTART QUIZ</button>
        </div>
    </div>
</div>

<footer class="footer py-5" style="background: #020617; color: #94a3b8; border-top: 4px solid #D4AF37;">
        <div class="container-fluid text-center"> <img src="images/logo-taif.png" style="height: 65px; filter: brightness(0) invert(1); margin-bottom: 25px;" alt="Taif University Logo">
            <p class="mb-1 text-white" style="font-size: 1.1rem; font-weight: 700;">
                Taif University - University College at Khurma
            </p>
            <p class="mb-4" style="letter-spacing: 1px; font-weight: 500;">
                Department of Computer Science
            </p>
            <div class="row justify-content-center mb-4 text-center">
                <div class="col-auto"><span class="badge px-4 py-2 shadow-sm" style="background:#D4AF37; color:white; border-radius: 50px; font-weight: 600; font-size: 0.85rem;">Section: 286</span></div>
                <div class="col-auto"><span class="badge px-4 py-2 shadow-sm" style="background:#D4AF37; color:white; border-radius: 50px; font-weight: 600; font-size: 0.85rem;">Project 2026</span></div>
            </div>
            <hr style="background-color: #334155; width: 60%; margin: 30px auto;">
            <p class="small text-muted" style="font-style: italic;">Developed for Educational Purposes © 2026 | Networking Course Project</p>
        </div>
    </footer>

<script>
    const myQuestions = <?php echo json_encode($db_questions); ?>;
    let currentIdx = 0;
    let userScore = 0;

    function renderQuestion() {
        if (myQuestions.length === 0) {
            document.getElementById("q-text").innerText = "No questions available.";
            return;
        }
        const activeQ = myQuestions[currentIdx];
        document.getElementById("q-number").innerText = `Question ${currentIdx + 1}/${myQuestions.length}`;
        document.getElementById("q-text").innerText = activeQ.q;
        document.getElementById("p-bar").style.width = ((currentIdx + 1) / myQuestions.length * 100) + "%";

        const optBox = document.getElementById("options-box");
        optBox.innerHTML = "";
        activeQ.options.forEach((opt, i) => {
            const div = document.createElement("div");
            div.className = "col-md-6";
            const btn = document.createElement("button");
            btn.className = "option-item animate__animated animate__fadeIn";
            btn.innerText = opt;
            btn.onclick = () => {
                const all = document.querySelectorAll(".option-item");
                all.forEach(b => b.style.pointerEvents = "none");
                if (i === activeQ.correct) {
                    userScore++;
                    btn.classList.add("is-correct");
                    document.getElementById("score-text").innerText = `Score: ${userScore}`;
                } else {
                    btn.classList.add("is-wrong");
                    all[activeQ.correct].classList.add("is-correct");
                }
                setTimeout(() => {
                    currentIdx++;
                    if (currentIdx < myQuestions.length) renderQuestion();
                    else {
                        document.getElementById("quiz-active").style.display = "none";
                        document.getElementById("result-area").style.display = "block";
                        document.getElementById("final-score-display").innerText = `${userScore}/${myQuestions.length}`;
                    }
                }, 1000);
            };
            div.appendChild(btn);
            optBox.appendChild(div);
        });
    }
    window.onload = renderQuestion;
</script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

</body>
</html>